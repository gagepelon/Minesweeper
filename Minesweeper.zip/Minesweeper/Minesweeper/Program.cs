﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Minesweeper;

namespace Minesweeper
{
    /*
     * Gage Pelon
     * Minesweeper program for PTL as part of the interview process
     * 13 August 2019
    */
    class Program
    {
        public static string MNStr = "", strM = "", strN = "";
        public static char[] tmpC = null;
        public static int index = 0, M = 0, N = 0, j = 0, fn = -1, cnt = 0, r = 0, c = 0, g = 0;
        public static bool fl = true; // True means that M and N are real values
        public static char[,,] field = new char[100, 100, 100]; // [fn, M, N]
        public static string[] dim = new string[100];
        public static string[] tmpR = new string[10];
        public static string[,,] fOut = new string[100,100,100];

        static public void Main(string[] args)
        {
            Console.WriteLine("Welcome to Minesweeper!\n" +
                "Please enter the MxN field size followed by the field.\n" +
                "Enter '0 0' for field size when finished.\n");

            start:
            // Get M & N
            GetMN(MNStr,true);
            if (MNStr == "0 0") { goto finish; }

            while (M != 0 && N != 0) // Keep taking fields until done
            {
                fn = fn + 1; // Field number count
                if (fl == false) // Not a real number for M or N
                {
                    Console.WriteLine("Please enter a valid number for M and N.");
                    goto start;
                }
                else
                {
                    dim[fn] = MNStr;
                }                

                // Save minefield
                Array.Resize(ref tmpR, M);                                
                for (int i = 0; i < M; i++) // Save letters to 1D char array
                {
                    tmpR[i] = Console.ReadLine();
                    tmpC = string.Join(string.Empty, tmpR).ToCharArray();
                    //Console.WriteLine(tmpR[i]); //debug
                }
                j = 0;
                for (r = 0; r < M; r++) // Save letters to 3D char array
                {
                    for (c = 0; c < N; c++)
                    {
                        field[fn, r, c] = tmpC[j];
                        j++;
                    }                    
                }

                Globals.field = field;
                Console.WriteLine();
                GetMN(MNStr, true);
            }

            // ------------ Output ------------- //
            //int z = 1;
            //GetMN(dim[0], false);
            //string[,,] fOut = new string[fn+1, M, N];
            for (int f = -1; f<fn; f++) // Each field
            {
                GetMN(dim[f + 1], false);
                for (r = 0; r < M; r++) // Each row
                {
                    for (c = 0; c < N; c++) // Each col
                    {
                        cnt = 0;
                        if (field[f + 1,r,c] == '*') // If cell is bomb, mark as bomb
                        {
                            fOut[f + 1, r, c] = "*";
                        }
                        else // If cell is not bomb, count bombs around cell
                        {
                            if (IsReal(r - 1, c, N, field[f + 1, r, c]) == true)
                            {
                                if (field[f + 1, r - 1, c] == '*')
                                {
                                    cnt++;
                                }
                            }
                            if (IsReal(r + 1, c, N, field[f + 1, r, c]) == true)
                            {
                                if (field[f + 1, r + 1, c] == '*')
                                {
                                    cnt++;
                                }
                            }
                            if (IsReal(r, c + 1, N, field[f + 1, r, c]) == true)
                            {
                                if (field[f + 1, r, c + 1] == '*')
                                {
                                    cnt++;
                                }
                            }
                            if (IsReal(r, c - 1, N, field[f + 1, r, c]) == true)
                            {
                                if (field[f + 1, r, c - 1] == '*')
                                {
                                    cnt++;
                                }
                            }
                            if (IsReal(r - 1, c + 1, N, field[f + 1, r, c]) == true)
                            {
                                if (field[f + 1, r - 1, c + 1] == '*')
                                {
                                    cnt++;
                                }
                            }
                            if (IsReal(r - 1, c - 1, N, field[f + 1, r, c]) == true)
                            {
                                if (field[f + 1, r - 1, c - 1] == '*')
                                {
                                    cnt++;
                                }
                            }
                            if (IsReal(r + 1, c + 1, N, field[f + 1, r, c]) == true)
                            {
                                if (field[f + 1, r + 1, c + 1] == '*')
                                {
                                    cnt++;
                                }
                            }
                            if (IsReal(r + 1, c - 1, N, field[f + 1, r, c]) == true)
                            {
                                if (field[f + 1, r + 1, c - 1] == '*')
                                {
                                    cnt++;
                                }
                            }
                            fOut[f + 1, r, c] = cnt.ToString();
                        }
                    }
                }
            }

            for (int f = -1; f < fn; f++) // Each field
            {
                GetMN(dim[f + 1], false);
                Console.WriteLine("\nField #{0}", f + 2);
                for (r = 0; r < M; r++) // Each row
                {
                    for (c = 0; c < N; c++) // Each col
                    {
                        Console.Write(fOut[f + 1, r, c]);
                    }
                    Console.WriteLine();
                }
            }

            finish:
            Console.WriteLine("\nProgram Terminated.\n" +
                "Press any key to exit...");
            Console.ReadKey();
        }

        static bool IsReal(int r, int c, int N, char cell)
        {
            return (r >= 0) && (r < N) &&
                   (c >= 0) && (c < N);
        }

        static Tuple <int, int, bool, string> GetMN(string str, bool full)
        {
            if (full == true)
            {
                MNStr = Console.ReadLine();
                str = MNStr;
            }
            else { }
            index = str.IndexOf(' ');
            strM = "";
            for (int i = 0; i < index; i++)
            {
                strM = strM + str[i];
            }
            strN = "";
            for (int i = index; i < str.Length; i++)
            {
                strN = strN + str[i];
            }

            // Convert MNStr to int
            bool success = Int32.TryParse(strM, out M);
            success = Int32.TryParse(strN, out N);
            if (success) // i.e. As long as entry contains valid numbers, proceed
            {
                Globals.M = M;
                Globals.N = N;
            }
            else
            {
                fl = false;
            }
            return Tuple.Create(M, N, fl, MNStr);
        }
    }

    class Globals
    {
        public static int M = 0, N = 0;
        public static char[,,] field = new char[100, M, N];
    }
}
